import './App.css';
import Wordle from './components/Wordle';

function App() {
  return (
    <div className="App">
      <Wordle />
    </div>
  );
}

export default App;
